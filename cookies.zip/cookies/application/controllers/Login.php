<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	 public function __construct(){

	     parent::__construct();

	     // Load model
	     $this->load->model('Login_model');
	     $this->load->library('form_validation');
	     $this->load->helper('url');
	     $this->load->library('session');
  	}
	
	public function index()
	{
		$this->load->view('login');
	}

	public function validate()
	{
		$user = $this->input->post('username');
		$password = $this->input->post('password');

		if($user == 'admin@gmail.com' && $passsword = 'admin@123')
			{
				$this->session->set_flashdata('msg', 'Admin Login Successfully');
				$this->load->view('dashboard');
			}else
			{
				$this->session->set_flashdata('errormsg', 'Admin username or password mismatched');
				redirect('Login/index');
			}
	}


	public function productlist()
	{
		$data['list'] = $this->Login_model->getProductlist();
		$this->load->view('productslist',$data);
	}

	public function addproducts()
	{

		$this->load->view('productsadd');
	}

	public function saveproducts()
	{

		//echo "<pre>";print_r($_FILES);exit;
		 $config['upload_path'] = 'uploads/'; 
         $config['allowed_types'] = '*'; 
         $config['max_size'] = '100'; // max_size in kb 
         $config['file_name'] = $_FILES['image']['name'];
        
         // Load upload library 
         $this->load->library('upload',$config); 
   
         // File upload
         if($this->upload->do_upload('image')){ 
            // Get data about the file
            $uploadData = $this->upload->data(); 
            $filename = $uploadData['file_name']; 
             //echo "<pre>";print_r($filename);exit;
         }
		$name = $this->input->post('name');
		$price = $this->input->post('price');
		$desc = $this->input->post('desc');

		//image upload
		 
		
		$data = array(
			'name'=>$name,
			'price'=>$price,
			'description'=>$desc,
			'image'=>$filename,
			'created_at'=>date('Y-m-d H:i:s'),
		);

		// echo "<pre>";print_r($data);exit;
		$insert = $this->Login_model->AddPoductDetails($data);
		if ($insert) 
		{
			$this->session->set_flashdata('msg', 'Product Added Successfully');
			redirect('Login/productlist');
		}
		
		//echo $insert;exit;
	}

	public function productedit()
	{
		$id = $_GET['id'];
		$data['editlist'] = $this->Login_model->getProductdata($id);
		$this->load->view('editproduct',$data);
	}


	public function updateproducts()
	{
		//echo "<pre>";print_r($_FILES);exit;
		$id = $this->input->post('id');
		$name = $this->input->post('name');
		$price = $this->input->post('price');
		$desc = $this->input->post('desc');

		if(isset($_FILES['image']['name']) && !empty($_FILES['image']['name']))
		{
		 $config['upload_path'] = 'uploads/'; 
         $config['allowed_types'] = '*'; 
         $config['max_size'] = '100'; // max_size in kb 
         $config['file_name'] = $_FILES['image']['name'];
        
         // Load upload library 
         $this->load->library('upload',$config); 
   
         // File upload
         if($this->upload->do_upload('image')){ 
            // Get data about the file
            $uploadData = $this->upload->data(); 
            $filename = $uploadData['file_name']; 
             //echo "<pre>";print_r($filename);exit;
         }


         $data = array(
			'name'=>$name,
			'price'=>$price,
			'description'=>$desc,
			'image'=>$filename,
			'created_at'=>date('Y-m-d H:i:s'),
		);

		// echo "<pre>";print_r($data);exit;
		$insert = $this->Login_model->UpdatePoductDetails($data,$id);
		if ($insert) 
		{
			$this->session->set_flashdata('msg', 'Product Updated Successfully');
			redirect('Login/productlist');
		}
	}else{
		echo "select Image";
		redirect('Login/productlist');
	}
	}


	public function productdelete()
	{
		$id = $_GET['id'];
		$delete = $this->Login_model->DeleteProductdata($id);

		if ($delete) 
		{
			$this->session->set_flashdata('msg', 'Product Deleted Successfully');
			redirect('Login/productlist');
		}
		

	}


	public function cart()
	{
		$id = $_GET['id'];

		$data['cart'] = $this->Login_model->getProductcart($id);

		$this->load->view('cart',$data);
	}

	
}
