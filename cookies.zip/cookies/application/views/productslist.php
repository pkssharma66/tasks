<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.10.13/datatables.min.css"/>
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.13/datatables.min.js"></script>  
	
</head>
<body>
    <div class="container">
        <a href="<?php echo  base_url();?>Login/addproducts" class="btn btn-primary">Add</a>
        <a href="<?php echo  base_url();?>Welcome/index" class="btn btn-warning">Logout</a>
    </div>
    <br>
<div class="container">
<?php //echo "<pre>";print_r($list);exit;?>
<?php if ($this->session->flashdata('msg')) { ?>
    <div class="alert alert-success"> <?= $this->session->flashdata('msg') ?> </div>
<?php 
if(isset($_SESSION['msg'])){
    unset($_SESSION['msg']);
}
 } ?>
<table id="example" class="display" style="width:100%">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>price</th>
                <th>Desctiption</th>
                <th>Product</th>
                <th>Action</th>
                
            </tr>
        </thead>
        <tbody>
            <?php 
                foreach ($list as $res) 
                {
                 ?>
                 <tr>
                <td><?php echo $res['id'];?></td>
                <td><?php echo $res['name'];?></td>
                <td><?php echo $res['price'];?></td>
                <td><?php echo $res['description'];?></td>
                <td>
                    <img src= "<?php echo base_url("uploads/"). $res['image'];?>" height="100px" width="100px" alt="<?php echo $res['name'];?>" >
                </td>

               <td><a href="<?php echo base_url();?>/Login/productedit?id=<?php echo $res['id'];?>" class="btn btn-primary">Edit</a>
                <a href="<?php echo base_url();?>/Login/productdelete?id=<?php echo $res['id'];?>" class="btn btn-danger">Delete</a>
               </td>
                
            </tr> 
            <?php 
                }
            ?>
            
            
        </tbody>
        
    </table>
</div>
    </body>
</html>

<script type="text/javascript">
	$(document).ready(function() {
    $('#example').DataTable();
} );
</script>