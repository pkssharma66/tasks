<!DOCTYPE html>
<html>
<head>
    <title>Dash Board</title>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css
">
</head>
<body>
    <?php if ($this->session->flashdata('msg')) { ?>
    <div class="alert alert-success"> <?= $this->session->flashdata('msg') ?> </div>
<?php 
if(isset($_SESSION['msg'])){
    unset($_SESSION['msg']);
}
 } ?>
<div class="jumbotron">
<div class="row w-100">
        
        <div class="col-md-12">
            <div class="card-header">
                <h3>Admin Dashboard</h3>
            </div>
            <div class="card-body">
                <div class="card border-success mx-sm-1 p-3">
                
                    <div class="text-success text-center mt-3"><h4><a href="<?php echo base_url()?>Login/productlist">View Products</a></h4></div>
                
                 </div>
            </div>
            
        </div>
       
     </div>
</div>
</body>
</html>

