<!DOCTYPE html>
<html>
<head>
    <title>Products</title>
    <!-- Bootstrap core CSS -->
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
</head>
<body>
   
    <div id="login">
        <h3 class="text-center text-white pt-5">Product Add form</h3>
        <div class="container">
             <?php if ($this->session->flashdata('errormsg')) { ?>
                <div class="alert alert-danger"> <?= $this->session->flashdata('errormsg') ?> </div>
            <?php 
                if(isset($_SESSION['errormsg'])){
                    unset($_SESSION['errormsg']);
                }
             } ?>
            <div id="login-row" class="row justify-content-center align-items-center">
                <div id="login-column" class="col-md-6">
                    <div id="login-box" class="col-md-12">
                        <form id="login-form" action="<?php echo base_url();?>Login/updateproducts" class="form" method="post" enctype="multipart/form-data">
                            <h3 class="text-center text-info">Edit</h3>
                            <?php //echo "<pre>";print_r($editlist);exit;?>
                            <input type="text" name="id" value="<?php echo $editlist['id'];?>"">
                            <div class="form-group">
                                <label for="username" class="text-info">Product Name:</label><br>
                                <input type="text" name="name" id="name" class="form-control" value="<?php echo $editlist['name'];?>">
                            </div>
                            <div class="form-group">
                                <label for="password" class="text-info">Price:</label><br>
                                <input type="text" name="price" id="price" class="form-control" value="<?php echo $editlist['price'];?>">
                            </div>
                            <div class="form-group">
                                <label for="password" class="text-info">Description:</label><br>
                                <textarea name="desc" id="desc" class="form-control" value="<?php echo $editlist['price'];?>""></textarea> 
                            </div>
                            <div class="form-group">
                                <label for="password" class="text-info">Image:</label><br>
                                <input type="file" name="image" id="image" class="form-control">
                                <img src= "<?php echo base_url("uploads/"). $editlist['image'];?>" height="100px" width="100px" alt="<?php echo $editlist['name'];?>" name="image" id="image">
                            </div>
                            
                            <div class="form-group">
                                
                                <input type="submit" name="submit" id="submit" class="btn btn-info btn-md" value="Update">
                            </div>
                            
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>

<script>
    $(document).ready(function(){
       $("#login-form").validate({
        rules: {
            name:"required",
            price:"required",
            desc:"required",
            image:"required"
        },
        messages:{
            name : {
                required : "please provide the username"
            },
            price : {
                required : "please provide the price"
            },
            desc : {
                required : "please select the desc"
            },
            image: {
              required : "please select the Image"
            }

        }
       });

       // $("#submit").on('click',function(e){
       //  e.preventDefault();
       //  var user = $('#username').val();
       //  var pass = $('#password').val();
       //  var state = $('#status').val();
       //  if (user == '' || user == undefined) {
       //      $('#username').css('border', '1px solid red');
       //      flag = 1;
       //  }
       //  if (pass == '' || pass == undefined) {
       //      $('#password').css('border', '1px solid red');
       //      flag = 1;
       //  }
       //  $.ajax({
       //      url:"<?php echo base_url();?>Login/validate",
       //      type : "POST",
       //      data :{user:user,pass:pass,state:state},
            
       //  });
       // })
    })
</script>

</html>
    



