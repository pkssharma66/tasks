<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Login_model extends CI_Model {


  //admin process

  function getProductlist()
  {
    $this->db->select("*");
    $result = $this->db->get("products")->result_array();
    return $result;
  }

  function AddPoductDetails($data)
  {
    return $this->db->insert('products',$data);
  }

  function getProductdata($id)
  {
    $this->db->select("*");
    $this->db->where('id',$id);
    $result = $this->db->get('products')->row_array();
    return $result;
  }

  function UpdatePoductDetails($data,$id)
  {
    $this->db->where('id',$id);
    $result = $this->db->update('products',$data);
    return $result;
  }

  function DeleteProductdata($id)
  {
    $this->db->where('id',$id);
    $result = $this->db->delete('products');
    return $result;

  }

  function getProductcart($id)
  {
    $this->db->select("*");
    $this->db->where('id',$id);
    $result = $this->db->get('products')->row_array();
    return $result;
  }

}