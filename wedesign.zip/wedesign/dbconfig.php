<?php
$conn = new mysqli("localhost","root","","wedesign");

if(!$conn)
{
	die("Database error".mysqli_error($conn));
}
?>