<?php
include('dbconfig.php');

if(isset($_POST['id']))
{
	$id = $_POST['id'];

	$query = "select * from city where stateid = '$id' ";
	
	$res = mysqli_query($conn,$query);

	while($row = mysqli_fetch_assoc($res))
	{
		$id = $row['id'];
		$city = $row['cityname'];
	?>

		<option value="<?php echo $id;?>"><?php echo $city;?></option>
	<?php
	}
}

?>