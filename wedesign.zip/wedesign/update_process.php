<?php
session_start();
include_once('dbconfig.php');

//echo "<pre>";print_r($_POST);exit;
	if(isset($_POST['register']) && !empty($_POST['register']))
	{
		//Image and file uplaod
		
			
			$id = $_POST['id'];
			$name = $_POST['username'];
			$dob = date('Y-m-d',strtotime($_POST['dob']));
			$age = $_POST['age'];
			$phone = $_POST['phone'];
			$email = $_POST['email'];
			$Address = $_POST['Address'];
			$state = $_POST['state'];
			$city = $_POST['city'];
			$password = $_POST['password'];
			
			if(isset($_FILES['profile_image']) && !empty($_FILES['profile_image']))
			{
			//Image Uplaod
			$profile = $_FILES['profile_image'];
			$file_name = $profile['name'];
			$file_type = $profile ['type'];
			$file_size = $profile ['size'];
			$file_path = $profile ['tmp_name'];
				if(move_uploaded_file ($file_path,'images/'.$file_name)){
					$image = $file_name;
				}
			}

			
		
	

	$sql ="UPDATE users SET name = '$name', email = '$email', phone = '$phone',age='$age', address = '$Address', state='$state', city='$city', password='$password',image = '$image' WHERE id = '$id'";
		//	echo $sql;exit;
		//use for MySQLi OOP
		if(mysqli_query($conn,$sql)){
			$_SESSION['success'] = 'User Details updated successfully';
			header('location:list.php');
		}
		
		else{
			$_SESSION['Error'] = 'Something went wrong while adding';
			header('location:edit.php');
		}
	}
		

	
?>