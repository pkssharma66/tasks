<?php
session_start();
include('dbconfig.php');
$id = $_GET['id'];
 $sql = mysqli_query($conn,"select * from users left join state ON state.id = users.state left join city ON city.id = users.city where users.id='$id'");
?>
<!DOCTYPE html>
<html>
<head>
  <title>Login</title>
  <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  <link rel="stylesheet" type="text/css" href="assets/css/style.css">
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
  <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->
</head>
<body>
  <div class="container">
      <div class="row">
      <div class="col-md-6 col-md-offset-3">
        <div class="panel panel-login">
          <div class="panel-heading">
            <div class="row">
              <div class="col-xs-6">
                <a href="#" id="register-form-link">Update</a>
              </div>
            </div>
            <hr>
          </div>
          <div class="panel-body">
            
            <div class="row">
              <div class="col-lg-12">
               
                <form id="register-form" action="update_process.php" method="post" role="form" style="display: block;" enctype="multipart/form-data">
                	<?php 
                	if(mysqli_num_rows($sql) > 0)
                	{
                		while ($res = mysqli_fetch_assoc($sql)) {?>
                			
                		 <input type="hidden" name="id" id="id"  placeholder="Username" value="<?php echo $res['id'];?>">
                  <div class="form-group">
                    <input type="text" name="username" id="username" tabindex="1" class="form-control" placeholder="Username" value="<?php echo $res['name'];?>">
                  </div>
                  <div class="form-group">
                    <input type="text" name="dob" id="dob" tabindex="2" class="form-control" placeholder="DOB" value="<?php echo $res['dob'];?>" autocomplete="off">
                  </div>
                  <div class="form-group">
                    <input type="age" name="age" id="age" tabindex="3" class="form-control" placeholder="Age" value="<?php echo $res['age'];?>" readonly="">
                  </div>
                  <div class="form-group">
                    <input type="text" name="phone" id="phone" tabindex="4" class="form-control" placeholder="Phone" value="<?php echo $res['phone'];?>">
                  </div>
                  <div class="form-group">
                    <input type="email" name="email" id="email" tabindex="5" class="form-control" placeholder="Email Address" value="<?php echo $res['email'];?>">
                  </div>
                  <div class="form-group">
                    <input type="text" name="Address" id="Address" tabindex="6" class="form-control" placeholder="Address" value="<?php echo $res['address'];?>">
                  </div>
                  <div class="form-group">
                    <select name="state" id="state" tabindex="7" class="form-control">
                      <option value="<?php echo $res['id'];?>"><?php echo $res['statename'];?></option>
                    </select>
                  </div>
                  <div class="form-group">
                    <select name="city" id="city" tabindex="8" class="form-control">
                     <option value="<?php echo $res['id'];?>"><?php echo $res['cityname'];?></option>
                    </select>
                  </div>
                  <div class="form-group">
                    <input type="password" name="password" id="password" tabindex="9" class="form-control" placeholder="Password" value="<?php echo $res['password'];?>">
                  </div>
                  <div class="form-group">
                    <input type="file" name="profile_image" id="profile_image" tabindex="10" class="form-control" placeholder="profile_image">
                    <img src="images/<?php echo $res['image'];?>" height="100px" width="100px">
                  </div>
                  <div class="form-group">
                    <div class="row">
                      <div class="col-sm-6 col-sm-offset-3">
                        <input type="submit" name="register" id="register" tabindex="11" class="form-control btn btn-register" value="Update">
                      </div>
                    </div>
                  </div>
              <?php }
                	}
                	?>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</body>
<script type="text/javascript" src="assets/js/jquery.validate.min.js"></script>
<script src="http://code.jquery.com/ui/1.11.0/jquery-ui.js"></script>
<script>
  $(document).ready(function(){
       var age = "";
        $('#dob').datepicker({
            onSelect: function(value, ui) {
                var today = new Date();
                age = today.getFullYear() - ui.selectedYear;
                $('#age').val(age);
            },
            
        });

        $("#register-form").validate({

      rules:{
        username : "required",
        dob:"required",
        email: {
          required: true,
          email: true
        },
        phone: {
          required: true,
          number: true,
          minlength: 10,
          maxlength: 14
        },
        Address:"required",
        state : "required",
        city:"required",
        password:"required",
        profile_image:"required",
        
      },
       messages : {
            username: {
              required: "Provide UserName"
            },
            dob: {
              required: "Provide DOB"
            },
            phone: {
              required : "Provide phone No"
              
            },
            email: {
              required: "Provide Email",
              email: "Provide valid email"
            },
            Address: {
              required: "Provide Address"
            },
            state: {
              required: "Provide state"
            },
            city: {
              required: "Provide city"
            },
            password: {
              required: "Provide Password"
            },
            
        }
      
    });

        
  });
</script>

<script>
  $(function() {

  	$('#register-form-link').click(function(e) {
    $("#register-form").delay(100).fadeIn(100);
    $("#login-form").fadeOut(100);
    $('#login-form-link').removeClass('active');
    $(this).addClass('active');
    e.preventDefault();
  });
    $('#login-form-link').click(function(e) {
    $("#login-form").delay(100).fadeIn(100);
    $("#register-form").fadeOut(100);
    $('#register-form-link').removeClass('active');
    $(this).addClass('active');
    e.preventDefault();
  });
  

});
</script>
</html>


