<?php
session_start();
include_once('dbconfig.php');

$user = $_POST['username'];
$password = $_POST['password'];
$status = $_POST['status'];

	if($status == 1)
	{
		if($user == 'admin@gmail.com' && $password =='admin@123')
		{
		//echo"1";exit;
			$_SESSION['success'] = 'Admin Login Successfully';
			header('location: adminpannel.php');
			$_SESSION['email'] = $user;
		}else
		{
			$_SESSION['Error'] = 'Admin login credentials mismatch';
			header('location: index.php');
		}
	}else if($status == 2)
	{
		$password1 = md5($_POST['password']);
		if($user !='' && $password1 !='')
		{
			$sql = "select * from users where email = '$user'";

			$res = mysqli_query($conn,$sql);

			if(mysqli_num_rows($res) > 0)
			{
				
				while($row = mysqli_fetch_assoc($res))
				{
					//echo "<pre>";print_r($row);exit;
					if($row['password'] == $password1)
					{
						//echo"1";exit;
						$_SESSION['email'] = $user;
						$_SESSION['success'] = 'UserLogin Successfully successfully';
						header('location:list.php');
					}
					else
					{
						//echo"2";exit;
						$_SESSION['Error'] = 'User Mail and password mismatched';
						header('location: index.php');
					}
				}
			}else{
				$_SESSION['Error'] = 'User Mail  Does not exist';
				header('location: index.php');
			}
		}else{
			$_SESSION['Error'] = 'login details are given empty';
			header('location: index.php');
		}
	}else{
			$_SESSION['Error'] = 'provide login details';
			header('location: index.php');	
	}
				
			
			
		
?>