<?php
session_start();
include('dbconfig.php');
if(isset($_POST['sendmail'])){

$mail = $_POST['mail'];

$sql = "select * from users where email = '$mail'";

$res = mysqli_query($conn,$sql);

$count = mysqli_num_rows($res);

if($count == 1)
{
	$row = mysqli_fetch_assoc($res);
	
	$password = $row['password'];
	$to = $mail;
	//echo"<pre>";print_r($to);exit;	
	$subject = "Forgot Password link";
	$message ="Your Password is" . "\n\n" . $password;
	
	$headers = "From:pkssharma66@gmail.com" ;
	$mail = mail($to,$subject,$message,$headers);
	
	//echo "<pre>";print_r($mail);exit;
		if(isset($mail))
		{
			//echo 1;exit;
			echo "Your Password has been sent to your email id";
		}else{
			//echo 3;exit;
			echo "Failed to Recover your password, try again";
		}
 
	}else{
		echo "User name does not exist in database";
	}
}

	//echo "Mail Sent. Thank you " . $to . ", we will contact you shortly.";

?>