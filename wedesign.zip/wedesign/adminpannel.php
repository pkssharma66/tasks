<?php
session_start();
$user = $_SESSION['email'];
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>List</title>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.4/css/jquery.dataTables.min.css">
    <style>
        .height10{
            height:10px;
        }
        .mtop10{
            margin-top:10px;
        }
        .modal-label{
            position:relative;
            top:7px
        }
    </style>
</head>
<body>
<div class="container">
    <div class="row">
        <div >
            <span class="profile">Welcome <?php echo $user;?>
            <a href="logout.php">Logout</a></span>
        </div>
    </div>
    <h1 class="page-header text-center">Task</h1>
    <div class="row">
        <div class="col-sm-8 col-sm-offset-2">
            <div class="row">
            <?php
                
                if(isset($_SESSION['success'])){
                    echo
                    "
                    <div class='alert alert-success text-center'>
                        <button class='close'>&times;</button>
                        ".$_SESSION['success']."
                    </div>
                    ";
                    unset($_SESSION['success']);
                }
            ?>
            </div>
            <div class="row">
                <div>
                    <div class="row">
                        <div class="col-md-3">
                            <p><a href="add_user.php" class="btn btn-danger">Add</a></p>
                        </div>
                        <div class="col-md-9">
                            <table id="myTable" class="table table-bordered table-striped table-responsive">
                                <thead>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Password</th>
                                    
                                </thead>
                                <tbody>
                                    <?php
                                        include_once('dbconfig.php');
                                        $sql = "SELECT * FROM users";

                                        //use for MySQLi-OOP
                                        $query = $conn->query($sql);
                                        while($row = $query->fetch_assoc()){
                                            echo 
                                            "<tr>
                                                <td>".$row['id']."</td>
                                                <td>".$row['name']."</td>
                                                <td>".$row['email']."</td>
                                                <td>".$row['password']."</td>
                                                
                                            </tr>";
                                            
                                        }
                                        

                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php //include('add_modal.php') ?>

<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="datatable/jquery.dataTables.min.js"></script>
<script src="datatable/dataTable.bootstrap.min.js"></script>

<!-- generate datatable on our table -->
<script>
$(document).ready(function(){
    //alert("datatable")
    //inialize datatable
    $('#myTable').DataTable();

    //hide alert
    $(document).on('click', '.close', function(){
        $('.alert').hide();
    })
});
</script>
