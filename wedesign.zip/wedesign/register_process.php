<?php
session_start();
include_once('dbconfig.php');

//echo "<pre>";print_r($_POST);exit;
	if(isset($_POST['register']))
	{
		//Image and file uplaod
		$file = $_FILES['profile_image'];
		$file_name = $file['name'];
		$file_type = $file ['type'];
		$file_size = $file ['size'];
		$file_path = $file ['tmp_name'];


		if(move_uploaded_file ($file_path,'images/'.$file_name)){
			
			$username = $_POST['username'];
			$dob = date('Y-m-d',strtotime($_POST['dob']));
			$age = $_POST['age'];
			$phone = $_POST['phone'];
			$email = $_POST['email'];
			$Address = $_POST['Address'];
			$state = $_POST['state'];
			$city = $_POST['city'];
			$password = md5($_POST['password']);
			$image = $file_name;
			
		}
	

	$sql = "INSERT INTO users VALUES('','$username', '$age','$dob','$email', '$phone','$Address','$state','$city','$password','$image')";
		//echo $sql;exit;
		//use for MySQLi OOP
		if(mysqli_query($conn,$sql)){
			$_SESSION['success'] = 'User Details added successfully';
			header('location: index.php');
		}
		
		else{
			$_SESSION['error'] = 'Something went wrong while adding';
			header('location: index.php');
		}
	}
		

	
?>